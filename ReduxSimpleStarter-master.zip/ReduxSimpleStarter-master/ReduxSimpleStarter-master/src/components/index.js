module.exports = require('./slider');
